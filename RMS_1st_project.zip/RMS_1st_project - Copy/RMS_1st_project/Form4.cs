﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace RMS_1st_project
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=HP\SQLEXPRESS;Initial Catalog=RMS;Integrated Security=True");
            SqlCommand cmd;
            string strcommand = "select * from register";
            DataTable table = new DataTable();
            con.Open();
            cmd = new SqlCommand(strcommand, con);
            SqlDataAdapter adap = new SqlDataAdapter();
            adap.SelectCommand = cmd;
            adap.Fill(table);
            con.Close();
            dataGridView1.DataSource = table;

            for (int i = 0; i < table.Rows.Count; i++)
            {
                comboBox1.Items.Add(table.Rows[i]["NAME"].ToString());
                comboBox2.Items.Add(table.Rows[i]["FLATNO"].ToString());
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 home = new Form2();
            this.Hide();
            home.Show();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string flatno = comboBox2.Text;
            string name = comboBox1.Text;

            SqlConnection con = new SqlConnection(@"Data Source=HP\SQLEXPRESS;Initial Catalog=RMS;Integrated Security=True");
            SqlCommand cmd;
            string strcommand = "select * from register where FLATNO='"+flatno+"' OR NAME='"+name+"'";
            DataTable table = new DataTable();
            con.Open();
            cmd = new SqlCommand(strcommand, con);
            SqlDataAdapter adap = new SqlDataAdapter();
            adap.SelectCommand = cmd;
            adap.Fill(table);
            con.Close();
            dataGridView1.DataSource = table;

        }
    }
}
