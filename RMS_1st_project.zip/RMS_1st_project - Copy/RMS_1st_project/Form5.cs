﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace RMS_1st_project
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            dataGridView1.Hide();
            SqlConnection con = new SqlConnection(@"Data Source=HP\SQLEXPRESS;Initial Catalog=RMS;Integrated Security=True");
            SqlCommand cmd;
            string strcommand = "select * from rentupdate";
            DataTable table = new DataTable();
            con.Open();
            cmd = new SqlCommand(strcommand, con);
            SqlDataAdapter adap = new SqlDataAdapter();
            adap.SelectCommand = cmd;
            adap.Fill(table);
            con.Close();
            //dataGridView1.DataSource = table;
            for (int i = 0; i < table.Rows.Count; i++)
            {
                comboBox1.Items.Add(table.Rows[i]["NAME"].ToString());
                comboBox2.Items.Add(table.Rows[i]["FLATNO"].ToString());
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 home = new Form2();
            this.Hide();
            home.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string flatno = comboBox2.Text;
            string name = comboBox1.Text;

            SqlConnection con = new SqlConnection(@"Data Source=HP\SQLEXPRESS;Initial Catalog=RMS;Integrated Security=True");
            SqlCommand cmd;
            string strcommand = "select * from rentupdate where FLATNO='" + flatno + "' OR NAME='" + name + "'";
            DataTable table = new DataTable();
            con.Open();
            cmd = new SqlCommand(strcommand, con);
            SqlDataAdapter adap = new SqlDataAdapter();
            adap.SelectCommand = cmd;
            adap.Fill(table);
            con.Close();
            dataGridView1.Show();
            dataGridView1.DataSource = table;

        }

        private void button3_Click(object sender, EventArgs e)
        {            
            string strcommand1 = string.Empty;
            SqlConnection con = new SqlConnection(@"Data Source=HP\SQLEXPRESS;Initial Catalog=RMS;Integrated Security=True");
            SqlCommand cmd1;
            strcommand1 = "update rentupdate set " +comboBox3.Text+ "='"+textBox1.Text+"' where FLATNO='" +comboBox2.Text+ "';";
            con.Open();
            cmd1 = new SqlCommand(strcommand1, con);
            cmd1.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Successfully Updated");

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
