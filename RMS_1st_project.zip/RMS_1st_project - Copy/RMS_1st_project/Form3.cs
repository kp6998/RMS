﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace RMS_1st_project
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }



        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string z = comboBox1.Text;
            string Gender = string.Empty;
            if (radioButton1.Checked) Gender = "M";
            else if (radioButton2.Checked) Gender = "F";
            else Gender = "T";

            string strcommand = string.Empty;
            string strcommand1 = string.Empty;

            SqlConnection con = new SqlConnection(@"Data Source=HP\SQLEXPRESS;Initial Catalog=RMS;Integrated Security=True");
            SqlConnection con1 = new SqlConnection(@"Data Source=HP\SQLEXPRESS;Initial Catalog=RMS;Integrated Security=True");
            SqlCommand cmd, cmd1;
            strcommand = "insert into register (FLATNO,NAME,GENDER,MOBILE,EMAIL,SHARING,VEHICLES,MOTHERLANG,ADDRESS) values ('" + z + "','" + textBox3.Text + "','" + Gender + "','" + textBox1.Text + "','" + textBox2.Text + "','" + textBox4.Text + "','" + textBox6.Text + "','" + textBox5.Text + "','" + textBox7.Text + "')";
            strcommand1 = "insert into rentupdate (FLATNO,NAME) values ('" + z + "','" + textBox3.Text + "')";

            con.Open();
            cmd = new SqlCommand(strcommand, con);
            cmd.ExecuteNonQuery();
            con.Close();

            con1.Open();
            cmd1 = new SqlCommand(strcommand1, con1);
            cmd1.ExecuteNonQuery();
            con1.Close();

            MessageBox.Show("Registered successful");

            Form2 done = new Form2();
            this.Hide();
            done.Show();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form3_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=HP\SQLEXPRESS;Initial Catalog=RMS;Integrated Security=True");
            SqlCommand cmd;
            string strcommand = "select * from register";
            DataTable table = new DataTable();
            con.Open();
            cmd = new SqlCommand(strcommand, con);
            SqlDataAdapter adap = new SqlDataAdapter();
            adap.SelectCommand = cmd;
            adap.Fill(table);
            con.Close();

            int a = 0;
            for (int j = 1; j <= 50; j++)
            {
                int p=0;
                for (int i = 0; i < table.Rows.Count; i++)
                {
                    a = Convert.ToInt16(table.Rows[i]["FLATNO"]);
                    if (j != a)
                    {
                        p++;
                    }
                }
                if (p == table.Rows.Count)
                    comboBox1.Items.Add(+j);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 home = new Form2();
            this.Hide();
            home.Show();
        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
